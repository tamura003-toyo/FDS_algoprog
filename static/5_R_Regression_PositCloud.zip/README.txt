第5回 Rによる回帰分析（RStudio / Posit Cloud）

1. ZIPを展開し、Rmdとtomato.xlsxを同じフォルダに置きます。
   Posit CloudではFiles → UploadでZIPをアップロードすると展開されます。
2. 5_R_Regression.Rmdを開き、冒頭にあるパッケージをConsoleでインストールします（初回のみ）。
3. コードを上から実行します。A1〜A8は授業中、R1〜R5は復習です。
4. 解答例は折りたたみ内にあります。HTMLはKnitで作成できます。
図はRmdに埋め込まれており、別の画像フォルダは不要です。
